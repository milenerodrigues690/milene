let jardineiro;
let plantas = [];
let temperatura = 10;
let totalArvores = 0;

function setup() {
  createCanvas(600, 400);
  jardineiro = new Jardineiro(width / 2, height - 50);  // Criação do jardineiro
}

function draw() {
  // Cor de fundo baseada no número de árvores plantadas
  let corFundo = lerpColor(color(217, 112, 26), color(219, 239, 208), map(totalArvores, 0, 100, 0, 1));
  background(corFundo);
 
  mostrarInformacoes();  // Exibe as informações do jogo
 
  temperatura += 0.1;  // Aumenta a temperatura gradualmente
  jardineiro.atualizar();  // Atualiza a posição do jardineiro
  jardineiro.mostrar();  // Exibe o jardineiro
 
  plantas.forEach((arvore) => arvore.mostrar());  // Exibe todas as árvores plantadas

  // Verifica se o jogo acabou
  verificarFimDeJogo();
}

// Função para mostrar informações na tela
function mostrarInformacoes() {
  textSize(26);
  fill(0);
  text("Vamos plantar arvores para reduzir a temperatura?", 10, 30);
  textSize(14);
  fill('white');
  text("Temperatura: " + temperatura.toFixed(2), 10, 390);
  text("Árvores plantadas: " + totalArvores, 460, 390);
  text("Para movimentar o personagem, use as setas do teclado", 10, 60);
  text("Para plantar árvores, use P ou espaço", 10, 80);
}

// Função para verificar se o jogo acabou
function verificarFimDeJogo() {
  if (totalArvores > temperatura) {
    mostrarMensagemDeVitoria();
  } else if (temperatura > 50) {
    mostrarMensagemDeDerrota();
  }
}

// Função para mostrar mensagem de vitória
function mostrarMensagemDeVitoria() {
  textSize(32);
  fill(0, 255, 0);  // Cor verde
  text("Você venceu!", width / 2 - 100, height / 2);
}

// Função para mostrar mensagem de derrota
function mostrarMensagemDeDerrota() {
  textSize(32);
  fill(255, 0, 0);  // Cor vermelha
  text("Você perdeu!", width / 2 - 100, height / 2);
}

// Função que será chamada quando a tecla for pressionada
function keyPressed() {
  if (key === ' ' || key === 'p') {
    let arvore = new Arvore(jardineiro.x, jardineiro.y);  // Cria uma nova árvore
    plantas.push(arvore);  // Adiciona a árvore ao array de plantas
    totalArvores++;  // Incrementa o contador de árvores plantadas
    temperatura -= 3;  // Diminui a temperatura ao plantar uma árvore
    if (temperatura < 0) temperatura = 0;  // Garante que a temperatura não fique negativa
  }
}

// Classe para o jardineiro
class Jardineiro {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.velocidade = 5;
  }

  atualizar() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.velocidade;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.velocidade;
    }
    if (keyIsDown(UP_ARROW)) {
      this.y -= this.velocidade;
    }
    if (keyIsDown(DOWN_ARROW)) {
      this.y += this.velocidade;
    }
  }

  mostrar() {
    fill(0);
    ellipse(this.x, this.y, 50, 50);  // Representação simples do jardineiro como um círculo
  }
}

// Classe para as árvores
class Arvore {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.tamanho = 20;
  }

  mostrar() {
    fill(34, 139, 34);  // Cor verde para a árvore
    ellipse(this.x, this.y, this.tamanho, this.tamanho);  // Representação simples da árvore
  }
}

